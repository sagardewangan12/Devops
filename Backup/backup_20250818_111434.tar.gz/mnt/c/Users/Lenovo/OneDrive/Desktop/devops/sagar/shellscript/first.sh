#!/bin/bash

echo "simple print"
