#!/bin/bash

#greet(){
#     echo "hello user"
#}

#greet

#greet1(){
#   echo "name:$1"
#   echo "age:$2"
#}

#greet1 "sagar" "23"

#sum of user values
#echo "value1:"
#read a
#echo "value2:"
#read b

#add(){
#   result=$(($1 + $2))
#    echo "$1 + $2 = $result"
#}

#add "$a" "$b"


#fun calling fun
#sq(){
#  a1=$(( $1 * $1 ))
#    echo "$a1"
#}

#dis(){
#  sq "$1"
#}

#echo "enter values for sq:"
#read x
#dis "$x"
