#!/bin/bash

#print
#echo "hello"

#print name

#user="sagar"
#echo "hello $user"

#user input
#echo "enter name:"
#read name
#echo "hello $name"

#conditional statement
#echo "enter no:"
#read num
#if [ $num -gt 10 ]; then
#  echo "$num is greator than 10"
#else
#  echo "$num is smaller than 10"
#fi


