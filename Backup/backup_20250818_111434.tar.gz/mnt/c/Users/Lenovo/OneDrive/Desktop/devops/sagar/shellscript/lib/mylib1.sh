#!/bin/bash

greet(){
  echo "hello $1! welcome to devops plan"
}

timest(){
  date +"%Y-%m-%d %H:%M:%S"
}
