#!/bin/bash

source ./mylib1.sh

greet "sagar"

echo "current time is=$(timest)"
